#pragma once
#include "graphics/GrRenderer.h"
#include "graphics/RayIntersection.h"
#include <list>
#include "graphics/GrTransform.h"
class CMyRaytraceRenderer :
    public CGrRenderer
{
public:
    CMyRaytraceRenderer();
    ~CMyRaytraceRenderer();
    void SetImage(BYTE** image, int width, int height);
    void SetWindow(CWnd* p_window);
    void RendererMaterial(CGrMaterial* p_material);
    bool RendererStart();
    void RendererPushMatrix();
    void RendererPopMatrix();
    void RendererRotate(double angle, double x, double y, double z);
    void RendererTranslate(double x, double y, double z);
    void RendererEndPolygon();
    bool RendererEnd();
    void RayColor(const CRay& ray, std::vector<double>& color, int recurse, const CRayIntersection::Object* ignore);
    void shading();

    void texture2D(const CGrTexture* texture, const CGrPoint texcoord, std::vector<double>& tcolor);

    //CGrColor RayColor(const CRay& p_ray);

private:
    int     m_rayimagewidth;
    int     m_rayimageheight;
    BYTE** m_rayimage;
    CWnd* m_window;
    CRayIntersection m_intersection;
    std::list<CGrTransform> m_mstack;
    CGrMaterial* m_material;
};

