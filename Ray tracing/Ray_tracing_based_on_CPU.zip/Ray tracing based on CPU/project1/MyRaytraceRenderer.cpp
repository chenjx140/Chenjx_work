#include "pch.h"
#include "MyRaytraceRenderer.h"
#include "Graphics/GrTexture.h"

CMyRaytraceRenderer::CMyRaytraceRenderer()
{
	m_window = NULL;
}

CMyRaytraceRenderer::~CMyRaytraceRenderer()
{
    
}

void CMyRaytraceRenderer::SetImage(BYTE** image, int width, int height)
{
	m_rayimage = image;
	m_rayimagewidth = width;
	m_rayimageheight = height;
}
void CMyRaytraceRenderer::SetWindow(CWnd* p_window)
{
	m_window = p_window;
}
void CMyRaytraceRenderer::RendererMaterial(CGrMaterial* p_material)
{
	m_material = p_material;
}
bool CMyRaytraceRenderer::RendererStart()
{
	m_mstack.clear();
	m_intersection.Initialize();
	m_material = NULL;

	// We have to do all of the matrix work ourselves.
	// Set up the matrix stack.
	CGrTransform t;
	t.SetLookAt(Eye().X(), Eye().Y(), Eye().Z(),
		Center().X(), Center().Y(), Center().Z(),
		Up().X(), Up().Y(), Up().Z());

	m_mstack.push_back(t);
    // Configure any lights
    //for (int i = 0; i < LightCnt(); i++)
    //{
    //    //glEnable(GL_LIGHT0 + i);

    //    GLfloat lightpos[4];
    //    for (int j = 0; j < 4; j++)
    //        lightpos[j] = GLfloat(GetLight(i).m_pos[j]);
    //    RendererTranslate(lightpos[0], lightpos[1], lightpos[2]);



    //}
	return true;
}

void CMyRaytraceRenderer::RendererPushMatrix()
{
	m_mstack.push_back(m_mstack.back());
}

void CMyRaytraceRenderer::RendererPopMatrix()
{
	m_mstack.pop_back();
}

void CMyRaytraceRenderer::RendererRotate(double angle, double x, double y, double z)
{
    CGrTransform trans;
    trans.SetRotate(angle, CGrPoint(x, y, z));
    m_mstack.back() *= trans;
    
}

void CMyRaytraceRenderer::RendererTranslate(double x, double y, double z)
{
	CGrTransform trans;
	trans.SetTranslate(x, y, z);
	m_mstack.back() *= trans;
    auto a = m_mstack.back();
}

//
// Name : CMyRaytraceRenderer::RendererEndPolygon()
// Description : End definition of a polygon. The superclass has
// already collected the polygon information
//

void CMyRaytraceRenderer::RendererEndPolygon()
{
    const std::list<CGrPoint>& vertices = PolyVertices();
    const std::list<CGrPoint>& normals = PolyNormals();
    const std::list<CGrPoint>& tvertices = PolyTexVertices();

    // Allocate a new polygon in the ray intersection system
    m_intersection.PolygonBegin();
    m_intersection.Material(m_material);

    if (PolyTexture())
    {
        m_intersection.Texture(PolyTexture());
    }

    std::list<CGrPoint>::const_iterator normal = normals.begin();
    std::list<CGrPoint>::const_iterator tvertex = tvertices.begin();

    for (std::list<CGrPoint>::const_iterator i = vertices.begin(); i != vertices.end(); i++)
    {
        if (normal != normals.end())
        {
            m_intersection.Normal(m_mstack.back() * *normal);
            normal++;
        }

        if (tvertex != tvertices.end())
        {
            m_intersection.TexVertex(*tvertex);
            tvertex++;
        }

        m_intersection.Vertex(m_mstack.back() * *i);
    }

    m_intersection.PolygonEnd();
}

bool CMyRaytraceRenderer::RendererEnd()
{
    m_intersection.LoadingComplete();

	double ymin = -tan(ProjectionAngle() / 2 * GR_DTOR);
	double yhit = -ymin * 2;

	double xmin = ymin * ProjectionAspect();
	double xwid = -xmin * 2;

	for (int r = 0; r < m_rayimageheight; r++)
	{
        //m_window->Invalidate();
       // m_window->UpdateWindow();
        for (int c = 0; c < m_rayimagewidth; c++)
        {
            double x = xmin + (c + 0.5) / m_rayimagewidth * xwid;
            double y = ymin + (r + 0.5) / m_rayimageheight * yhit;

            // Construct a Ray
            CRay ray(CGrPoint(0, 0, 0), Normalize3(CGrPoint(x, y, -1, 0)));

            


            std::vector<double> color(3,0);
            color[0] = color[1] = color[2] = 0.0;
            RayColor(ray, color, 20, NULL);
          
            
            if (color[0] > 255.0)
            {
                color[0] = 255.0;
            }
            if (color[1] > 255.0)
            {
                color[1] = 255.0;
            }
            if (color[2] > 255.0)
            {
                color[2] = 255.0;
            }
            if (color[0] < 0.0)
            {
                color[0] = 0.0;
            }  
            if (color[1] < 0.0)
            {
                color[1] = 0.0;
            }
            if (color[2] < 0.0)
            {
                color[2] = 0.0;
            }
            m_rayimage[r][c * 3] = BYTE(color[0]);
            m_rayimage[r][c * 3 + 1] = BYTE(color[1]);
            m_rayimage[r][c * 3 + 2] = BYTE(color[2]);
        }
        

	}

    return true;
}


void CMyRaytraceRenderer::RayColor(const CRay& ray, std::vector<double>& color, int recurse, const CRayIntersection::Object* ignore) 
{
    //start here replacement
    //get color of ray hit;
    double t;                                   // Will be distance to intersection
    CGrPoint intersect;                         // Will by x,y,z location of intersection
    const CRayIntersection::Object* nearest;    // Pointer to intersecting object
    color[0] = color[1] = color[2] = 0.0;
    if (m_intersection.Intersect(ray, 1e20, ignore, nearest, t, intersect))
    {
        // We hit something...
        // Determine information about the intersection
        CGrPoint N;
        //test
        CGrMaterial* material;
        CGrTexture* texture;
        CGrPoint texcoord;

        m_intersection.IntersectInfo(ray, nearest, t,
            N, material, texture, texcoord);

        //fill info following blinn-phong model
        if (material != NULL)
        {
            //lignting implememnt aaaa
            for (int rgbi = 0; rgbi < 1; rgbi++) 
            {
                double shading = 0.3;
                for (int i = 0; i < LightCnt(); i++)
                {
                    if (i == 1)
                    {
                        i = i;
                    }
                    double t2;                                   // Will be distance to intersection
                    CGrPoint intersect2;                         // Will by x,y,z location of intersection
                    const CRayIntersection::Object* nearest2;    // Pointer to intersecting object
                    CRay rayShadow(intersect, Normalize3(CGrPoint(GetLight(i).m_pos.X(), GetLight(i).m_pos.Y(), GetLight(i).m_pos.Z(), 0)));


                    if (!m_intersection.Intersect(rayShadow, t, nearest, nearest2, t2, intersect2))
                    {
                        if (recurse == 1)
                        {
                            recurse = recurse;
                        }//int p = i;
                        //blinn-phong
                        CGrPoint lightDr = Normalize3(GetLight(i).m_pos);
                        double Am = GetLight(i).m_ambient[rgbi];
                        double DF = GetLight(i).m_diffuse[rgbi];
                        double Sp = GetLight(i).m_specular[rgbi];
                        double Ka = m_material->Ambient(rgbi);
                        double Kd = m_material->Diffuse(rgbi);
                        double Ks = m_material->Specular(rgbi);
                        double shininess = m_material->Shininess();
                        
                        CGrPoint s = Normalize3(lightDr);
                        CGrPoint v = Normalize3(-ray.Direction());
                        CGrPoint n = Normalize3(N);
                        CGrPoint h = Normalize3(v + s);
                        double diffuse = Ka * Am + Kd * DF * max(0.0, Dot3(n, s));
                        double specular = Ks * Sp * pow(max(0.0, Dot3(n, h)), shininess);
                        shading += diffuse + specular;

                      
                        //start recurse condition here
                        if (recurse > 1 && (m_material->SpecularOther(0) > 0 || m_material->SpecularOther(1) > 0 || m_material->SpecularOther(2) > 0))
                        {
                            std::vector<double> colorReflected(3, 0);
                            CGrPoint R = n * 2 * Dot3(n, v) - v;
                            CRay rayReflected(intersect, R);
                            RayColor(rayReflected, colorReflected, recurse - 1, nearest);
                            for (int channel = 0; channel < 3; channel++)
                            {
                                color[channel] += material->SpecularOther(channel) * colorReflected[channel];
                            }
                        }
                    }

                }
                
                if (texture)
                {
                    shading *= 0.4;
                    for (int channel = 0; channel < 3; channel++)
                    {
                        int r = int(texcoord.Y() * (texture->Height() - 1));
                        int c = int(texcoord.X() * (texture->Width() - 1));
                        if (shading >= 1) {
                            shading = 1;
                        }
                        if (shading < 0) 
                        {
                            shading = 0;
                        }
                        color[channel] += (*texture)[r][c * 3 + channel] * shading;
                        //color[channel] = BYTE(255 * shading) test ;
                        
                    }
                }
                else 
                {
                    for (int channel = 0; channel < 3; channel++)
                    {
                        if (shading >= 1) {
                            shading = 1;
                        }
                        if (shading < 0)
                        {
                            shading = 0;
                        }
                        double colorM = material->Ambient(channel);
                        color[channel] += colorM * shading * 255;

                    }
                }
            }

        }
    }
    else
    {
        // We hit nothing...
    }
}
//replace end



void CMyRaytraceRenderer::texture2D(const CGrTexture* texture, const CGrPoint texcoord, std::vector<double>& tcolor)
{
    int r = int(round(texcoord.Y() * (texture->Height()) - 1));
    int c = int(round(texcoord.X() * (texture->Width()) - 1));
    auto tr = 0;
    auto tg = 0;
    auto tb = 0;
    if (r > 0 && c > 0)
    {
        tr = (*texture)[r][c * 3];
        tg = (*texture)[r][c * 3 + 1];
        tb = (*texture)[r][c * 3 + 2];
    }
    tcolor[0]=tr;
    tcolor[1]=tg;
    tcolor[2]=tb;
}