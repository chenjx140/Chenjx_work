
// ChildView.h : interface of the CChildView class
//


#pragma once
#include "graphics/OpenGLWnd.h"
#include "graphics/GrCamera.h"
#include "graphics/GrObject.h"
#include "graphics/GrTexture.h"

// CChildView window

class CChildView : public COpenGLWnd
{
// Construction
public:
	CChildView();

// Attributes
public:

// Operations
public:

// Overrides
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

// Implementation
public:
	virtual ~CChildView();

	// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
public:
	void ConfigureRenderer(CGrRenderer* p_renderer);
	void OnGLDraw(CDC* pDC);
private:
	CGrCamera m_camera;
	CGrPtr<CGrObject> m_scene;
	CGrTexture m_marble;
	CGrTexture m_wood;
	CGrTexture m_marble2;
	bool m_raytrace;
	BYTE** m_rayimage;
	int m_rayimagewidth;
	int m_rayimageheight;
public:
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnRenderRaytrace();
	afx_msg void OnUpdateRenderRaytrace(CCmdUI* pCmdUI);
};

